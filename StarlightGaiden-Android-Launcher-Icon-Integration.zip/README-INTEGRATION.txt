# StarlightGaiden Android Launcher Icon Integration

This overlay integrates the supplied Resident Evil Gaiden Remastered icon pack into
`regaiden-recomp/android/app/src/main/res/`.

## Apply

1. Copy this archive's `res/` directory into:
   `regaiden-recomp/android/app/src/main/res/`
2. Allow the files to merge/replace the matching launcher resources.
3. The audited upstream `AndroidManifest.xml` already declares:
   - `android:icon="@mipmap/ic_launcher"`
   - `android:roundIcon="@mipmap/ic_launcher_round"`
   No manifest edit is required for that revision.
4. Build the Android app again.

## Included

- Adaptive launcher icon for Android 8.0+ (`mipmap-anydpi-v26`), including monochrome layer.
- Legacy raster launcher icons for API 24–25 at mdpi through xxxhdpi.
- Circular legacy fallback for `ic_launcher_round`.
- App label: Resident Evil Gaiden Remastered.

The original 1024×1024 background, foreground, and monochrome PNG assets are retained.
The legacy fallback PNGs are generated from the supplied background and foreground.
